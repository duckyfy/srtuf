---
layout: "default"
title: "Redirecting..."
redirect: "https://discord.gg/bVNNHuQ"
---
If the browser not redirect you automatically please [click this link]({{ page.redirect }}).
