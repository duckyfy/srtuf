---
layout: "default"
title: "Redirecting..."
redirect: "https://discord.com/oauth2/authorize?client_id=681536055572430918&permissions=8&redirect_uri=https%3A%2F%2Figorkowalczyk.github.io%2Fmajobot%2Fauthorized&response_type=code&scope=guilds%20identify%20bot"
---
If the browser not redirect you automatically please [click this link]({{ page.redirect }}).
